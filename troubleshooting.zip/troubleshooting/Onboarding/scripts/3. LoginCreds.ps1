﻿$users = Import-Csv "C:\Users\pa.dkhan\Desktop\Onboarding\Windsor\NewUser.csv"

ForEach ($user in $users) {

echo ' '
echo $user.Name
echo ('UserName: ' + $user.GivenName + '.' + $user.Surname + '@' + $user.DomainName)
echo ('PassWord: ' + $user.Password)

}
