﻿$users = Import-Csv "C:\Users\pa.dkhan\Desktop\Onboarding\Windsor\NewUser.csv"

ForEach ($user in $users) {

$short = $user.SamAccountName

New-ADUser -Name $user.Name -GivenName $user.GivenName -Surname $user.Surname -DisplayName $user.DisplayName -Description $user.Description -Office $user.Office -SamAccountName $user.SamAccountName -Title $user.Title -Department $user.Department -Manager $user.Manager -StreetAddress $user.StreetAddress -City $user.City -State $user.State -PostalCode $user.PostalCode -Country $user.Country -Company $user.Company -Path $user.path -UserPrincipalName (($user.GivenName + '.' + $user.Surname + '@' + $user.DomainName).ToLower()) -ChangePasswordAtLogon $false  -AccountPassword ((ConvertTo-SecureString $user.Password -AsPlainText -Force)) -Enabled 1 -HomeDrive H -HomeDirectory \\etfsinc.com\profiles\userdata\employees-001\$short\documents
 
}
