﻿$users = Import-Csv "C:\Users\pa.dkhan\Desktop\Onboarding\Windsor\NewUser.csv"

ForEach ($user in $users) {

$ADUser = Get-ADUser -Filter "displayname -eq '$($user.name)'"

if($ADUser){
Get-ADUser -Identity $user.CopyFrom -Properties memberof | Select-Object -ExpandProperty memberof | Add-ADGroupMember -Members $user.SamAccountName
}else{
Write-Warning ("Failed to copy membership " + $($user.name))
}


}
